import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

public class RestaurantOrderProcessing {

    public static void main(String[] args) {
        LinkedList<String[]> allOrders = new LinkedList<>();
        LinkedList<String[]> foodStock = new LinkedList<>();
        LinkedList<String[]> drinkStock = new LinkedList<>();
        LinkedList<String[]> successfulOrders = new LinkedList<>();
        Queue<String[]> orderQueue = new LinkedList<>();
        Stack<String[]> failedOrders = new Stack<>();
        try {
            Scanner scanner = new Scanner(
                new File("src/lw02/unguided/orders.txt")
            );

            while (scanner.hasNext()) {

                String[] order = new String[4];

                order[0] = scanner.next(); 
                order[1] = scanner.next(); 
                order[2] = scanner.next(); 
                order[3] = scanner.next(); 

                allOrders.add(order);
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            System.out.println("dsa_5026221064/src/lw02/unguided/orders.txt not found.");
            return;
        }
        foodStock.add(new String[]{"Bakso", "2"});
        foodStock.add(new String[]{"Sate", "1"});
        foodStock.add(new String[]{"Soto", "2"});
        drinkStock.add(new String[]{"EsTeh", "4"});
        drinkStock.add(new String[]{"EsJeruk", "2"});
        while (!allOrders.isEmpty()) {
            orderQueue.add(allOrders.poll());
        }
        while (!orderQueue.isEmpty()) {

            String[] order = orderQueue.poll();

            boolean foodAvailable = true;
            boolean drinkAvailable = true;
            if (!order[1].equals("-")) {

                foodAvailable = false;

                for (String[] food : foodStock) {

                    if (food[0].equals(order[1])) {

                        if (Integer.parseInt(food[1]) > 0) {
                            foodAvailable = true;
                        }

                        break;
                    }
                }
            }
            if (!order[2].equals("-")) {

                drinkAvailable = false;

                for (String[] drink : drinkStock) {

                    if (drink[0].equals(order[2])) {

                        if (Integer.parseInt(drink[1]) > 0) {
                            drinkAvailable = true;
                        }

                        break;
                    }
                }
            }
            if (foodAvailable && drinkAvailable) {
                if (!order[1].equals("-")) {

                    for (String[] food : foodStock) {

                        if (food[0].equals(order[1])) {

                            int stock = Integer.parseInt(food[1]);

                            food[1] =
                                    String.valueOf(stock - 1);

                            break;
                        }
                    }
                }
                if (!order[2].equals("-")) {

                    for (String[] drink : drinkStock) {

                        if (drink[0].equals(order[2])) {

                            int stock =
                                    Integer.parseInt(drink[1]);

                            drink[1] =
                                    String.valueOf(stock - 1);

                            break;
                        }
                    }
                }
                successfulOrders.add(order);

            } else {
                failedOrders.push(order);
            }
        }
        System.out.println(
                "=== Successfully Processed Orders ==="
        );

        for (String[] order : successfulOrders) {

            System.out.println(
                    order[0] + " "
                    + order[1] + " "
                    + order[2] + " "
                    + order[3]
            );
        }
        System.out.println(
                "=== Remaining Food Stock ==="
        );

        for (String[] food : foodStock) {

            System.out.println(
                    food[0] + " : " + food[1]
            );
        }
        System.out.println(
                "=== Remaining Drink Stock ==="
        );

        for (String[] drink : drinkStock) {

            System.out.println(
                    drink[0] + " : " + drink[1]
            );
        }
        System.out.println(
                "=== Failed Orders ==="
        );

        while (!failedOrders.isEmpty()) {

            String[] order = failedOrders.pop();

            System.out.println(
                    order[0] + " "
                    + order[1] + " "
                    + order[2] + " "
                    + order[3]
            );
        }
    }
}