package lw03.unguided;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class CampusEvent {

    public static void main(String[] args) {
        Set<String> registeredStudents = new LinkedHashSet<>();
        Set<String> checkedInStudents = new LinkedHashSet<>();
        List<String> checkInResults = new ArrayList<>();
        int rejectedAttempts = 0;

        try {
            List<String> registrationIds = readStudentIds("registrations.txt");
            registeredStudents.addAll(registrationIds);
            List<String> checkInAttempts = readStudentIds("checkins.txt");

            for (String studentId : checkInAttempts) {
                if (!registeredStudents.contains(studentId)) {
                    checkInResults.add(studentId + ": Rejected (not registered)");
                    rejectedAttempts++;
                } else if (!checkedInStudents.add(studentId)) {
                    checkInResults.add(studentId + ": Rejected (already checked in)");
                    rejectedAttempts++;
                } else {
                    checkInResults.add(studentId + ": Checked in");
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: could not find input file '" + e.getMessage() + "'.");
            return;
        }

        System.out.println("===== Event Check-In Results =====");
        for (String result : checkInResults) {
            System.out.println(result);
        }

        int absentStudents = registeredStudents.size() - checkedInStudents.size();
        System.out.println();
        System.out.println("===== Final Event Summary =====");
        System.out.println("Registered students: " + registeredStudents.size());
        System.out.println("Successful check-ins: " + checkedInStudents.size());
        System.out.println("Absent students: " + absentStudents);
        System.out.println("Rejected attempts: " + rejectedAttempts);
    }

    private static List<String> readStudentIds(String fileName) throws FileNotFoundException {
        List<String> studentIds = new ArrayList<>();
        File inputFile = resolveInputFile(fileName);

        try (Scanner scanner = new Scanner(inputFile)) {
            while (scanner.hasNextLine()) {
                String studentId = scanner.nextLine().trim();
                if (studentId.isEmpty()) {
                    continue;
                }

                studentIds.add(studentId);
            }
        }

        return studentIds;
    }

    private static File resolveInputFile(String fileName) throws FileNotFoundException {
        String[] relativePaths = {
            "src/lw03/unguided/" + fileName,
            "dsa_5026221064/src/lw03/unguided/" + fileName,
            fileName
        };
        File currentDirectory = new File(System.getProperty("user.dir"));

        while (currentDirectory != null) {
            for (String relativePath : relativePaths) {
                File candidate = new File(currentDirectory, relativePath);
                if (candidate.isFile()) {
                    return candidate;
                }
            }
            currentDirectory = currentDirectory.getParentFile();
        }

        throw new FileNotFoundException(fileName);
    }
}
