import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class MapSetList {

    public static void main(String[] args) {
        String folder = resolvePrelabFolder();
        processPlaylist(folder + "/playlist.txt");
        processParticipants(folder + "/participants.txt");
        processInventory(folder + "/inventory.txt");
    }

    private static String resolvePrelabFolder() {
        String[] candidates = {
            "src/lw03/prelab",
            "dsa_5026221064/src/lw03/prelab"
        };

        for (String candidate : candidates) {
            if (new File(candidate + "/playlist.txt").exists()
                    || new File(System.getProperty("user.dir"), candidate + "/playlist.txt").exists()) {
                return candidate;
            }
        }

        return "src/lw03/prelab";
    }

    private static void processPlaylist(String fileName) {
        List<String> playlist = new ArrayList<>();

        try (Scanner scanner = new Scanner(resolveInputFile(fileName))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) {
                    continue;
                }

                String[] parts = line.split("\\s+", 3);
                String command = parts[0].toUpperCase();

                switch (command) {
                    case "ADD":
                        if (parts.length > 1) {
                            playlist.add(parts[1].trim());
                        }
                        break;
                    case "INSERT":
                        if (parts.length > 2) {
                            try {
                                int index = Integer.parseInt(parts[1]);
                                String song = parts[2].trim();
                                if (index < 0) {
                                    index = 0;
                                }
                                if (index > playlist.size()) {
                                    index = playlist.size();
                                }
                                playlist.add(index, song);
                            } catch (NumberFormatException ignored) {
                                // Ignore malformed index.
                            }
                        }
                        break;
                    case "REMOVE":
                        if (parts.length > 1) {
                            String song = parts[1].trim();
                            playlist.remove(song);
                        }
                        break;
                    default:
                        break;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: could not find file '" + fileName + "'.");
            return;
        }

        System.out.println("===== Problem 1 =====");
        System.out.println("Total songs: " + playlist.size());
        for (int i = 0; i < playlist.size(); i++) {
            System.out.println((i + 1) + ". " + playlist.get(i));
        }
        System.out.println();
    }

    private static void processParticipants(String fileName) {
        Set<String> uniqueParticipants = new LinkedHashSet<>();
        List<String> orderedParticipants = new ArrayList<>();
        int duplicateRegistrations = 0;

        try (Scanner scanner = new Scanner(resolveInputFile(fileName))) {
            while (scanner.hasNextLine()) {
                String name = scanner.nextLine().trim();
                if (name.isEmpty()) {
                    continue;
                }

                if (uniqueParticipants.add(name)) {
                    orderedParticipants.add(name);
                } else {
                    duplicateRegistrations++;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: could not find file '" + fileName + "'.");
            return;
        }

        System.out.println("===== Problem 2 =====");
        System.out.println("Unique participants: " + orderedParticipants.size());
        for (int i = 0; i < orderedParticipants.size(); i++) {
            System.out.println((i + 1) + ". " + orderedParticipants.get(i));
        }
        System.out.println("Duplicate registrations: " + duplicateRegistrations);
        System.out.println();
    }

    private static void processInventory(String fileName) {
        Map<String, Integer> inventory = new LinkedHashMap<>();
        List<String> productOrder = new ArrayList<>();
        int failedSales = 0;

        try (Scanner scanner = new Scanner(resolveInputFile(fileName))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) {
                    continue;
                }

                String[] parts = line.split("\\s+", 3);
                if (parts.length < 3) {
                    continue;
                }

                String type = parts[0].toUpperCase();
                String product = parts[1].trim();
                int quantity;

                try {
                    quantity = Integer.parseInt(parts[2].trim());
                } catch (NumberFormatException e) {
                    continue;
                }

                switch (type) {
                    case "ADD":
                        if (!inventory.containsKey(product)) {
                            inventory.put(product, 0);
                            productOrder.add(product);
                        }
                        inventory.put(product, inventory.get(product) + quantity);
                        break;
                    case "SELL":
                        if (!inventory.containsKey(product)) {
                            failedSales++;
                            break;
                        }

                        int currentStock = inventory.get(product);
                        if (currentStock >= quantity) {
                            inventory.put(product, currentStock - quantity);
                        } else {
                            failedSales++;
                        }
                        break;
                    default:
                        break;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: could not find file '" + fileName + "'.");
            return;
        }

        System.out.println("===== Problem 3 =====");
        for (String product : productOrder) {
            System.out.println(product + ": " + inventory.getOrDefault(product, 0));
        }
        System.out.println("Failed sales: " + failedSales);
        System.out.println();
    }

    private static File resolveInputFile(String relativePath) {
        File currentDir = new File(System.getProperty("user.dir"));
        File candidate = new File(currentDir, relativePath);
        if (candidate.exists()) {
            return candidate;
        }

        File path = new File(relativePath);
        if (path.exists()) {
            return path;
        }

        File root = currentDir;
        while (root != null) {
            File nestedCandidate = new File(root, relativePath);
            if (nestedCandidate.exists()) {
                return nestedCandidate;
            }
            root = root.getParentFile();
        }

        return new File(relativePath);
    }
}
