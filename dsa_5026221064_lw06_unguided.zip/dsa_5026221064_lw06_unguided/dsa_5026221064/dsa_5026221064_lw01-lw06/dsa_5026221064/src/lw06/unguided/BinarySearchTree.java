class BinarySearchTree {
    private Node root;

    public void insert(int data) {
        root = insertHelper(root, data);
    }

    private Node insertHelper(Node node, int data) {
        if (node == null) {
            return new Node(data);
        }
        if (data < node.data) {
            node.left = insertHelper(node.left, data);
        } else if (data > node.data) {
            node.right = insertHelper(node.right, data);
        }
        return node;
    }

    public boolean search(int target) {
        return searchHelper(root, target);
    }

    private boolean searchHelper(Node node, int target) {
        if (node == null) {
            return false;
        }
        if (target == node.data) {
            return true;
        }
        if (target < node.data) {
            return searchHelper(node.left, target);
        }
        return searchHelper(node.right, target);
    }

    public int countNodes() {
        return countNodesHelper(root);
    }

    private int countNodesHelper(Node node) {
        if (node == null) {
            return 0;
        }
        return 1 + countNodesHelper(node.left) + countNodesHelper(node.right);
    }

    public int countLeaves() {
        return countLeavesHelper(root);
    }

    private int countLeavesHelper(Node node) {
        if (node == null) {
            return 0;
        }
        if (node.left == null && node.right == null) {
            return 1;
        }
        return countLeavesHelper(node.left) + countLeavesHelper(node.right);
    }

    public String preOrder() {
        StringBuilder values = new StringBuilder();
        preOrderHelper(root, values);
        return values.toString();
    }

    private void preOrderHelper(Node node, StringBuilder values) {
        if (node == null) {
            return;
        }
        append(values, node.data);
        preOrderHelper(node.left, values);
        preOrderHelper(node.right, values);
    }

    public String inOrder() {
        StringBuilder values = new StringBuilder();
        inOrderHelper(root, values);
        return values.toString();
    }

    private void inOrderHelper(Node node, StringBuilder values) {
        if (node == null) {
            return;
        }
        inOrderHelper(node.left, values);
        append(values, node.data);
        inOrderHelper(node.right, values);
    }

    public String postOrder() {
        StringBuilder values = new StringBuilder();
        postOrderHelper(root, values);
        return values.toString();
    }

    private void postOrderHelper(Node node, StringBuilder values) {
        if (node == null) {
            return;
        }
        postOrderHelper(node.left, values);
        postOrderHelper(node.right, values);
        append(values, node.data);
    }

    private void append(StringBuilder values, int data) {
        if (values.length() > 0) {
            values.append(' ');
        }
        values.append(data);
    }
}
