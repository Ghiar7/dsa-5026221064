import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {

    private static InputStream openInput() throws IOException {
        InputStream stream = Main.class.getResourceAsStream("treenumbers.txt");
        if (stream == null) {
            stream = Main.class.getResourceAsStream("/treenumbers.txt");
        }
        if (stream == null) {
            stream = Main.class.getResourceAsStream("/lw06/unguided/treenumbers.txt");
        }
        if (stream != null) {
            return stream;
        }

        String[] candidates = {
            "treenumbers.txt",
            "src/lw06/unguided/treenumbers.txt",
            "dsa_5026221064/src/lw06/unguided/treenumbers.txt",
            "dsa_5026221064_lw01-lw06/dsa_5026221064/src/lw06/unguided/treenumbers.txt"
        };
        for (String location : candidates) {
            Path path = Paths.get(location);
            if (Files.isRegularFile(path)) {
                return new FileInputStream(path.toFile());
            }
        }
        throw new FileNotFoundException(
                "treenumbers.txt tidak ditemukan. Pastikan file ada di lw06/unguided.");
    }

    public static void main(String[] args) throws IOException {
        BinarySearchTree bst = new BinarySearchTree();
        int target;

        try (Scanner scanner = new Scanner(openInput(), StandardCharsets.UTF_8.name())) {
            String valuesLine = scanner.nextLine();
            try (Scanner values = new Scanner(valuesLine)) {
                while (values.hasNextInt()) {
                    bst.insert(values.nextInt());
                }
            }
            target = scanner.nextInt();
        }

        System.out.println("Preorder : " + bst.preOrder());
        System.out.println("Inorder : " + bst.inOrder());
        System.out.println("Postorder : " + bst.postOrder());
        System.out.println("Search " + target + " : " + bst.search(target));
        System.out.println("Nodes : " + bst.countNodes());
        System.out.println("Leaves : " + bst.countLeaves());
    }
}
