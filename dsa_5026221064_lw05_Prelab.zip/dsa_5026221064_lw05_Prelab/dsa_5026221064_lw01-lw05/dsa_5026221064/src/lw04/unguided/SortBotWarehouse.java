import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SortBotWarehouse {

    public static int[] bubbleSortDescending(int[] parcels) {
        int n = parcels.length;
        int[] afterTwoPasses = new int[n];

        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (parcels[j] < parcels[j + 1]) {
                    int temp = parcels[j];
                    parcels[j] = parcels[j + 1];
                    parcels[j + 1] = temp;
                }
            }

            if (i == 1) {
                for (int k = 0; k < n; k++) {
                    afterTwoPasses[k] = parcels[k];
                }
            }
        }

        return afterTwoPasses;
    }

    public static void binarySearchDescending(int[] parcels, int target) {
        int low = 0;
        int high = parcels.length - 1;
        int steps = 0;

        while (low <= high) {
            int mid = (low + high) / 2;
            steps++;

            if (parcels[mid] == target) {
                System.out.println(target + ": FOUND at index " + mid + " (steps: " + steps + ")");
                return;
            } else if (target > parcels[mid]) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }

        System.out.println(target + ": NOT FOUND (steps: " + steps + ")");
    }

    public static void printArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            if (i > 0) {
                System.out.print(" ");
            }
            System.out.print(array[i]);
        }
        System.out.println();
    }

    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("parcels.txt");
        if (!file.exists()) {
            file = new File("src/lw04/unguided/parcels.txt");
        }
        if (!file.exists()) {
            file = new File("lw04/unguided/parcels.txt");
        }

        int[] parcels;
        int[] targets;

        try (Scanner input = new Scanner(file)) {
            int n = input.nextInt();
            parcels = new int[n];
            for (int i = 0; i < n; i++) {
                parcels[i] = input.nextInt();
            }

            int m = input.nextInt();
            targets = new int[m];
            for (int i = 0; i < m; i++) {
                targets[i] = input.nextInt();
            }
        }

        int[] afterTwoPasses = bubbleSortDescending(parcels);

        System.out.println("==== After 2 Passes ====");
        printArray(afterTwoPasses);
        System.out.println();

        System.out.println("==== Fully Sorted ====");
        printArray(parcels);
        System.out.println();

        System.out.println("==== Search Results ====");
        for (int target : targets) {
            binarySearchDescending(parcels, target);
        }
    }
}
