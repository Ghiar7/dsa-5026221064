import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class timeHop {
    public static void insertionSort(int[] arr) {
        for (int i = 1; i <= 3; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] < key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        try {
            File file = new File("branches2.txt");
            Scanner sc = new Scanner(file);
            int N = sc.nextInt();
            int[] branches = new int[N];
            for (int i = 0; i < N; i++) {
                branches[i] = sc.nextInt();
            }
            int M = sc.nextInt();
            int[] targets = new int[M];
            for (int i = 0; i < M; i++) {
                targets[i] = sc.nextInt();
            }
            sc.close();
            insertionSort(branches);
            for (int i = 0; i < N; i++) {
                if (i > 0) {
                    System.out.print(" ");
                }
                System.out.print(branches[i]);
            }
            System.out.println();

            for (int i = 0; i < M; i++) {
                int index = linearSearch(branches, targets[i]);
                if (index != -1) {
                    System.out.println(
                        targets[i] + ": FOUND at index " + index
                    );
                } else {
                    System.out.println(
                        targets[i] + ": NOT FOUND"
                    );
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("File tidak ditemukan!");
        }
    }
}