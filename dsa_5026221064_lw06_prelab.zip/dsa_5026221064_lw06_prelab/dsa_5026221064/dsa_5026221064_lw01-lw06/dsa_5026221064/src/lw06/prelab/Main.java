import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Node {
    int data;
    Node left;
    Node right;

    Node(int data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}

public class Main {

    static Node insert(Node root, int data) {
        if (root == null) {
            return new Node(data);
        }
        if (data < root.data) {
            root.left = insert(root.left, data);
        } else if (data > root.data) {
            root.right = insert(root.right, data);
        }
        return root;
    }

    static boolean search(Node root, int target) {
        if (root == null) {
            return false;
        }
        if (target == root.data) {
            return true;
        }
        if (target < root.data) {
            return search(root.left, target);
        }
        return search(root.right, target);
    }

    static void preorder(Node root, StringBuilder result) {
        if (root == null) {
            return;
        }
        appendValue(result, root.data);
        preorder(root.left, result);
        preorder(root.right, result);
    }

    static void inorder(Node root, StringBuilder result) {
        if (root == null) {
            return;
        }
        inorder(root.left, result);
        appendValue(result, root.data);
        inorder(root.right, result);
    }

    static void postorder(Node root, StringBuilder result) {
        if (root == null) {
            return;
        }
        postorder(root.left, result);
        postorder(root.right, result);
        appendValue(result, root.data);
    }

    static void appendValue(StringBuilder result, int value) {
        if (result.length() > 0) {
            result.append(' ');
        }
        result.append(value);
    }

    static InputStream openInput() throws IOException {
        InputStream stream = Main.class.getResourceAsStream("/treenumbers.txt");
        if (stream == null) {
            stream = Main.class.getResourceAsStream("treenumbers.txt");
        }
        if (stream == null) {
            stream = Main.class.getResourceAsStream("/lw06/prelab/treenumbers.txt");
        }
        if (stream != null) {
            return stream;
        }

        String[] locations = {
            "treenumbers.txt",
            "src/lw06/prelab/treenumbers.txt",
            "dsa_5026221064/src/lw06/prelab/treenumbers.txt",
            "dsa_5026221064_lw01-lw06/dsa_5026221064/src/lw06/prelab/treenumbers.txt"
        };
        for (String location : locations) {
            Path path = Paths.get(location);
            if (Files.isRegularFile(path)) {
                return new FileInputStream(path.toFile());
            }
        }
        throw new FileNotFoundException("treenumbers.txt tidak ditemukan di folder lw06/prelab.");
    }

    public static void main(String[] args) throws IOException {
        Node root = null;
        int target;

        try (Scanner input = new Scanner(openInput(), StandardCharsets.UTF_8.name())) {
            String firstLine = input.nextLine();
            try (Scanner numbers = new Scanner(firstLine)) {
                while (numbers.hasNextInt()) {
                    root = insert(root, numbers.nextInt());
                }
            }
            target = input.nextInt();
        }

        StringBuilder pre = new StringBuilder();
        StringBuilder in = new StringBuilder();
        StringBuilder post = new StringBuilder();
        preorder(root, pre);
        inorder(root, in);
        postorder(root, post);

        System.out.println("Preorder : " + pre);
        System.out.println("Inorder   : " + in);
        System.out.println("Postorder : " + post);
        System.out.println("Search " + target + " : " + search(root, target));
    }
}
