import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;

public class Main {
    static int size;
    static String[] names;
    static int[][] graph;
    static int[] bfsLevel;
    static int[] bfsPrev;
    static int[] dijkstraPrev;
    static int[] shortestTime;

    static void addEdge(int from, int to, int minutes) {
        graph[from][to] = minutes;
        graph[to][from] = minutes;
    }

    static List<Integer> bfs(int start) {
        List<Integer> order = new ArrayList<>();
        Queue<Integer> queue = new LinkedList<>();
        Set<Integer> visited = new HashSet<>();

        bfsLevel = new int[size];
        bfsPrev = new int[size];
        Arrays.fill(bfsLevel, -1);
        Arrays.fill(bfsPrev, -1);

        queue.add(start);
        visited.add(start);
        bfsLevel[start] = 0;

        while (!queue.isEmpty()) {
            int current = queue.remove();
            order.add(current);

            for (int next = 0; next < size; next++) {
                if (graph[current][next] > 0 && !visited.contains(next)) {
                    visited.add(next);
                    queue.add(next);
                    bfsLevel[next] = bfsLevel[current] + 1;
                    bfsPrev[next] = current;
                }
            }
        }
        return order;
    }

    static void printLevels(int start, List<Integer> bfsOrder) {
        System.out.println("=== Station Levels from " + names[start] + " ===");
        int currentLevel = -1;

        for (int station : bfsOrder) {
            if (bfsLevel[station] != currentLevel) {
                currentLevel = bfsLevel[station];
                if (currentLevel > 0) {
                    System.out.println();
                }
                System.out.print("Level " + currentLevel + ": ");
            } else {
                System.out.print(", ");
            }
            System.out.print(names[station]);
        }
        System.out.println();
    }

    static void dijkstraAlg(int start) {
        int infinity = Integer.MAX_VALUE;
        shortestTime = new int[size];
        dijkstraPrev = new int[size];
        boolean[] visited = new boolean[size];

        Arrays.fill(shortestTime, infinity);
        Arrays.fill(dijkstraPrev, -1);
        shortestTime[start] = 0;

        for (int count = 0; count < size; count++) {
            int current = findTheNextNode(shortestTime, visited);
            if (current == -1) {
                break;
            }
            visited[current] = true;

            for (int next = 0; next < size; next++) {
                if (graph[current][next] > 0 && !visited[next]
                        && shortestTime[current] != infinity) {
                    int candidate = shortestTime[current] + graph[current][next];
                    if (candidate < shortestTime[next]) {
                        shortestTime[next] = candidate;
                        dijkstraPrev[next] = current;
                    }
                }
            }
        }
    }

    static int findTheNextNode(int[] distances, boolean[] visited) {
        int next = -1;
        int minimum = Integer.MAX_VALUE;
        for (int i = 0; i < size; i++) {
            if (!visited[i] && distances[i] < minimum) {
                minimum = distances[i];
                next = i;
            }
        }
        return next;
    }

    static List<Integer> buildPath(int[] prev, int start, int destination) {
        List<Integer> path = new ArrayList<>();
        int current = destination;

        while (current != -1) {
            path.add(current);
            if (current == start) {
                break;
            }
            current = prev[current];
        }

        Collections.reverse(path);
        if (path.isEmpty() || path.get(0) != start) {
            return new ArrayList<>();
        }
        return path;
    }

    static int pathTime(List<Integer> path) {
        int minutes = 0;
        for (int i = 0; i < path.size() - 1; i++) {
            minutes += graph[path.get(i)][path.get(i + 1)];
        }
        return minutes;
    }

    static void printPath(List<Integer> path) {
        for (int i = 0; i < path.size(); i++) {
            if (i > 0) {
                System.out.print(" -> ");
            }
            System.out.print(names[path.get(i)]);
        }
        System.out.println();
    }

    static void printSummary(List<Integer> fewestStops, List<Integer> fastest) {
        int fewestMinutes = pathTime(fewestStops);
        int fastestMinutes = pathTime(fastest);
        System.out.println("=== Comparison ===");
        if (fewestStops.equals(fastest)) {
            System.out.println("Both routes are the same.");
        } else {
            int savedMinutes = fewestMinutes - fastestMinutes;
            int extraStops = (fastest.size() - 1) - (fewestStops.size() - 1);
            System.out.println("The fastest route saves " + savedMinutes
                    + " min but needs " + extraStops + " more stops.");
        }
    }

    static InputStream openResource(String fileName) throws IOException {
        InputStream input = Main.class.getResourceAsStream(fileName);
        if (input != null) {
            return input;
        }

        String command = System.getProperty("sun.java.command", "");
        int nameEnd = command.lastIndexOf(".java");
        int nameStart = command.indexOf(' ');
        if (nameEnd >= 0 && nameStart >= 0 && nameStart < nameEnd) {
            String sourceName = command.substring(nameStart + 1, nameEnd + 5);
            Path javaFile = Paths.get(sourceName).toAbsolutePath();
            if (Files.isRegularFile(javaFile)) {
                URL directory = javaFile.getParent().toUri().toURL();
                URLClassLoader resources = new URLClassLoader(new URL[]{directory}, null);
                input = resources.getResourceAsStream(fileName);
                if (input != null) {
                    return input;
                }
                resources.close();
            }
        }

        throw new IOException("File " + fileName
                + " tidak ditemukan sebagai resource. Pastikan file ada di folder yang sama dengan Main.java.");
    }

    public static void main(String[] args) throws IOException {
        String inputName = args.length > 0 ? args[0] : "metro.txt";
        if (!inputName.equals("metro.txt") && !inputName.equals("metro1.txt")
                && !inputName.equals("metro2.txt")) {
            throw new IllegalArgumentException("Gunakan metro.txt, metro1.txt, atau metro2.txt.");
        }

        try (InputStream input = openResource(inputName);
             Scanner scanner = new Scanner(input, StandardCharsets.UTF_8)) {
            size = scanner.nextInt();
            names = new String[size];
            graph = new int[size][size];
            for (int i = 0; i < size; i++) {
                names[i] = scanner.next();
            }

            int edges = scanner.nextInt();
            for (int i = 0; i < edges; i++) {
                int from = scanner.nextInt();
                int to = scanner.nextInt();
                int minutes = scanner.nextInt();
                addEdge(from, to, minutes);
            }
            int start = scanner.nextInt();
            int destination = scanner.nextInt();

            List<Integer> visitingOrder = bfs(start);
            printLevels(start, visitingOrder);
            List<Integer> fewestStops = buildPath(bfsPrev, start, destination);

            dijkstraAlg(start);
            List<Integer> fastest = buildPath(dijkstraPrev, start, destination);

            System.out.println("=== Fewest Stops Route from " + names[start]
                    + " to " + names[destination] + " ===");
            printPath(fewestStops);
            System.out.println("Stops: " + (fewestStops.size() - 1)
                    + " | Time: " + pathTime(fewestStops) + " min");

            System.out.println("=== Fastest Route from " + names[start]
                    + " to " + names[destination] + " ===");
            printPath(fastest);
            System.out.println("Stops: " + (fastest.size() - 1)
                    + " | Time: " + pathTime(fastest) + " min");
            printSummary(fewestStops, fastest);
        }
    }
}
