import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;

public class Main {
    static int size;
    static String[] names;
    static int[][] graph;
    static List<Integer> dfsOrder = new ArrayList<>();

    // Jalur dapat dilewati dari kedua arah dengan waktu yang sama.
    static void addEdge(int from, int to, int minutes) {
        graph[from][to] = minutes;
        graph[to][from] = minutes;
    }

    // Tampilkan nama bangunan sesuai urutan indeks yang dikunjungi.
    static void printPath(List<Integer> order) {
        for (int i = 0; i < order.size(); i++) {
            if (i > 0) {
                System.out.print(" -> ");
            }
            System.out.print(names[order.get(i)]);
        }
        System.out.println();
    }

    // BFS memakai Queue dan Set. Tetangga diproses dari indeks terkecil.
    static List<Integer> bfs(int start) {
        List<Integer> order = new ArrayList<>();
        Set<Integer> visited = new HashSet<>();
        Queue<Integer> queue = new LinkedList<>();

        visited.add(start);
        queue.add(start);

        while (!queue.isEmpty()) {
            int current = queue.remove();
            order.add(current);

            for (int neighbour = 0; neighbour < size; neighbour++) {
                if (graph[current][neighbour] > 0 && !visited.contains(neighbour)) {
                    visited.add(neighbour);
                    queue.add(neighbour);
                }
            }
        }
        return order;
    }

    // DFS memakai rekursi dan Set, mengikuti nomor bangunan terkecil.
    static void dfs(int current, Set<Integer> visited) {
        visited.add(current);
        dfsOrder.add(current);

        for (int neighbour = 0; neighbour < size; neighbour++) {
            if (graph[current][neighbour] > 0 && !visited.contains(neighbour)) {
                dfs(neighbour, visited);
            }
        }
    }

    // Pilih simpul yang belum dikunjungi dengan jarak minimum.
    // Jika jaraknya sama, urutan loop memastikan indeks lebih kecil dipilih.
    static int findTheNextNode(int[] dist, boolean[] visited) {
        int next = -1;
        for (int i = 0; i < size; i++) {
            if (!visited[i] && (next == -1 || dist[i] < dist[next])) {
                next = i;
            }
        }
        return next;
    }

    // Bangun kembali rute dengan mengikuti array prev dari tujuan ke asal.
    static void route(int[] prev, int destination) {
        List<Integer> path = new ArrayList<>();
        for (int at = destination; at != -1; at = prev[at]) {
            path.add(0, at);
        }
        printPath(path);
    }

    // Dijkstra untuk bobot positif: jarak tercepat dan rutenya.
    static void dijkstraAlg(int start, int destination) {
        final int infinity = Integer.MAX_VALUE;
        int[] dist = new int[size];
        int[] prev = new int[size];
        boolean[] visited = new boolean[size];

        Arrays.fill(dist, infinity);
        Arrays.fill(prev, -1);
        dist[start] = 0;

        for (int step = 0; step < size; step++) {
            int current = findTheNextNode(dist, visited);
            if (current == -1 || dist[current] == infinity) {
                break;
            }
            visited[current] = true;

            for (int neighbour = 0; neighbour < size; neighbour++) {
                if (graph[current][neighbour] > 0 && !visited[neighbour]) {
                    int newDistance = dist[current] + graph[current][neighbour];
                    if (newDistance < dist[neighbour]) {
                        dist[neighbour] = newDistance;
                        prev[neighbour] = current;
                    }
                }
            }
        }

        System.out.println("=== Shortest Time from " + names[start] + " ===");
        for (int i = 0; i < size; i++) {
            System.out.println(names[i] + " : " + dist[i] + " min");
        }
        System.out.println("=== Shortest Route from " + names[start] + " to " + names[destination] + " ===");
        route(prev, destination);
        System.out.println("Total time: " + dist[destination] + " min");
    }

    public static void main(String[] args) throws FileNotFoundException {
        // Cari input di folder program atau di struktur proyek ketika Run/Debug dari root.
        File inputFile = new File("campus.txt");
        if (!inputFile.isFile()) {
            inputFile = new File("src/lw05/prelab/campus.txt");
        }
        if (!inputFile.isFile()) {
            inputFile = new File("dsa_5026221064/src/lw05/prelab/campus.txt");
        }
        if (!inputFile.isFile()) {
            inputFile = new File("dsa_5026221064_lw01-lw05/dsa_5026221064/src/lw05/prelab/campus.txt");
        }
        try (Scanner scanner = new Scanner(inputFile)) {
            size = scanner.nextInt();
            names = new String[size];
            for (int i = 0; i < size; i++) {
                names[i] = scanner.next();
            }

            graph = new int[size][size];
            int edgeCount = scanner.nextInt();
            for (int i = 0; i < edgeCount; i++) {
                int from = scanner.nextInt();
                int to = scanner.nextInt();
                int minutes = scanner.nextInt();
                addEdge(from, to, minutes);
            }

            int start = scanner.nextInt();
            int destination = scanner.nextInt();

            System.out.println("=== BFS from " + names[start] + " ===");
            printPath(bfs(start));

            dfsOrder.clear();
            dfs(start, new HashSet<Integer>());
            System.out.println("=== DFS from " + names[start] + " ===");
            printPath(dfsOrder);

            dijkstraAlg(start, destination);
        }
    }
}
